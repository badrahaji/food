const services = [
    { id:1,
      title: 'Restaurants',
      image: 'https://websitedemos.net/italian-restaurant-02/wp-content/uploads/sites/283/2019/12/Pizza-slice.jpg',
      description: 'Description du service 1.',
    },
    {id:2,
      title: 'Magasins',
      image: 'https://websitedemos.net/italian-restaurant-02/wp-content/uploads/sites/283/2019/12/Pizza-slice.jpg',
      description: 'Descrnjhiption du service 2.',
    },
    {id:2,
      title: 'Patessiries',
      image: 'https://websitedemos.net/italian-restaurant-02/wp-content/uploads/sites/283/2019/12/Pizza-slice.jpg',
      description: 'Description du service 3.',
    },
  ];
export default services