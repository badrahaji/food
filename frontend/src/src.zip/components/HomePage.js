import React from "react"
import Navb from "./Navbar"; 
import NosService from "./NosService "
import Menu from './Menu'
// import Footer from "./components/Footer";
const HomePage = () => {
    return (
<div>
    <Navb/>
{/* <Route  element={}></Route> */}
{/* <Route index  element={}></Route> */}
<NosService />
<Menu/>
{/* <Footer/> */}
</div>


    )
};
export default HomePage;





