
import React from "react"

const Offer = () => {
    return (
      <div className="header">
      <h1>Quality Ingredients, Tasty Meals </h1>
      <h3>Congue, gravida. Placeat nibh sunt semper elementum anim ! Integer lectus debitis auctor. 
        Molestias vivamus eligendi ut, cupidatat nisl iaculis etiam! Laboris aenean .</h3>
        </div>
    )
  }
  export default Offer